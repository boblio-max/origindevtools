# origin update cli
# origin doctor
# origin version

import os
import subprocess
from pathlib import Path
from .folder_gen import run
from .handle_java import handle_java_file
from .handle_python import handle_python_file
from .handle_origin import handle_origin_file, run_repl
from .install_lang import install_lang, uninstall_lang, update_lang
from .working_dir import change_working_directory


def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

title = """
========================================================
 ▄██████▄     ▄████████  ▄█    ▄██████▄    ▄█   ███▄▄▄▄
███    ███   ███    ███ ███  ███      ███ ███  ███▀▀▀██▄
███    ███   ███    ███ ███▌ ███      █▀  ███▌ ███   ███
███    ███  ▄███▄▄▄▄██▀ ███▌ ███          ███▌ ███   ███
███    ███ ▀▀███▀▀▀▀▀   ███▌ ███  ▀██████ ███▌ ███   ███
███    ███ ▀███████████ ███  ███      ███ ███  ███   ███
███    ███   ███    ███ ███  ███      ███ ███  ███   ███
 ▀██████▀    ▀█     █▀   █▀   ▀████████▀  █▀    ▀█   █▀
========================================================
"""
def handle_folder_gen(file_with_structure, location):
    run(file_with_structure, location)
    
def show_help():
    print("\nAvailable commands:")
    print("  origin help                                    - Show this help message")
    print("  origin clear                                   - Clear the console")
    print("  origin exit / oe                               - Exit the CLI")
    print("  origin <file>.or                               - Run an Origin file")
    print("  origin <file>.py                               - Run a Python file")
    print("  origin <file>.java                             - Compile and run a Java file")
    print("  origin <file>.class                            - Run a Java class file")
    print("  origin c <file>.java                           - Compile a Java file")
    print("  origin create <file_structure>.otxt <location> - Generates folder structure")
    print("  origin install <language>                      - Install a language")
    print("  origin uninstall <language>                    - Uninstall a language")
    print("  origin update <language>                       - Update    a language")
    print("  origin in <location>                           - Change working directory")
    print("  origin activate <venv_name>                    - Creates a python virtual environment")
    print("-" * 56)


def cli():
    clear_screen()
    print(title)
    print("Welcome to the Origin Interactive CLI!")
    print("Type 'origin help' for a list of commands.")

    running = True
    while running:
        try:
            cwd = Path.cwd()
            user_input = input(f"{cwd}> ").strip()
            if not user_input:
                continue

            parts = user_input.split()
            if parts[0] != "origin":
                print(f"Unknown command prefix. Did you mean 'origin {user_input}'?")
                continue
            
            if parts[0] == "oe":
                print("Exiting...")
                break
            
            if len(parts) < 2:
                run_repl()
                continue

            cmd_or_file = parts[1]

            # Command: help
            if cmd_or_file == "help":
                show_help()
            
            # Command: exit
            elif cmd_or_file == "exit":
                print("Exiting...")
                running = False
            
            # Command: clear
            elif cmd_or_file == "clear":
                clear_screen()
                print(title)

            # Command: compile (origin c <file>.java)
            elif cmd_or_file == "c":
                if len(parts) < 3:
                    print("Error: Please specify a .java file to compile.")
                else:
                    handle_java_file(parts[2], "compile")

            elif cmd_or_file == "install":
                if len(parts) < 3:
                    print("Error: Please specify a language to install.")
                else:
                    install_lang(parts[2])
            
            
            elif cmd_or_file == "uninstall":
                if len(parts) < 3:
                    print("Error: Please specify a language to uninstall.")
                else:
                    uninstall_lang(parts[2])
            
            elif cmd_or_file == "update":
                if len(parts) < 3:
                    print("Error: Please specify a language to update.")
                else:
                    update_lang(parts[2])
            
            elif cmd_or_file == "in":
                if len(parts) < 3:
                    print("Error: Please specify a location to change to.")
                else:
                    change_working_directory(parts[2])
            # File execution based on extension
            elif cmd_or_file.endswith(".or"):
                handle_origin_file(cmd_or_file)
            
            elif cmd_or_file.endswith(".py"):
                handle_python_file(cmd_or_file)
            
            elif cmd_or_file.endswith(".java"):
                handle_java_file(cmd_or_file, "run")
            
            elif cmd_or_file.endswith(".class"):
                handle_java_file(cmd_or_file, "run")

            elif cmd_or_file == "create":
                if len(parts) < 4:
                    print("Error: Please use the format: origin create <file_with_structure>.otxt <location>")
                else:
                    handle_folder_gen(parts[2], parts[3])
            elif parts[1] is None:
                run_repl()
        except EOFError:
            print("\nExiting...")
            break
        except KeyboardInterrupt:
            print("\nType 'origin exit' to quit.")
        except Exception as e:
            print(f"An error occurred: {e}")

def main():
    import sys
    if len(sys.argv) > 1:
        file_to_run = sys.argv[1]
        if file_to_run.endswith(".py"):
            handle_python_file(file_to_run)
        elif file_to_run.endswith(".java") or file_to_run.endswith(".class"):
            handle_java_file(file_to_run, "run")
        elif file_to_run.endswith(".or"):
            handle_origin_file(file_to_run)
        else:
            print(f"Error: Unknown file type '{file_to_run}'")
    else:
        cli()

if __name__ == "__main__":
    main()
